const fs = require('fs');
const path = require('path');

function convertImageToBase64(filePath) {
  try {
    const fileData = fs.readFileSync(filePath);
    const extension = path.extname(filePath).toLowerCase();
    let mimeType = 'image/jpeg';
    
    if (extension === '.png') {
      mimeType = 'image/png';
    } else if (extension === '.jpg' || extension === '.jpeg') {
      mimeType = 'image/jpeg';
    }
    
    const base64Data = fileData.toString('base64');
    return `data:${mimeType};base64,${base64Data}`;
  } catch (error) {
    console.error(`Error converting ${filePath} to base64:`, error);
    return null;
  }
}

// Convert the three images
const images = [
  { path: 'public/images/eid-template.jpg', name: 'eidTemplate' },
  { path: 'public/images/logo.jpg', name: 'logo' },
  { path: 'public/images/logo-white.png', name: 'logoWhite' }
];

let output = '// Base64 encoded images\n';

images.forEach(img => {
  const base64Data = convertImageToBase64(img.path);
  if (base64Data) {
    output += `export const ${img.name}Base64 = '${base64Data}';\n\n`;
  }
});

fs.writeFileSync('client/src/assets/base64Images.ts', output);
console.log('Images converted to base64 and saved to client/src/assets/base64Images.ts');
