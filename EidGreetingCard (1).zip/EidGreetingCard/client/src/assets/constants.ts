// Import base64 encoded images
import { eidTemplateBase64, logoBase64 } from './base64Images';

// Image data URLs (base64 encoded for direct embedding)
export const LOGO_URL = logoBase64;
export const EID_TEMPLATE_URL = eidTemplateBase64;

// Company information is now hardcoded in components to avoid import errors