export interface CardTemplate {
  id: string;
  name: string;
  orientation: 'landscape' | 'portrait';
  imageUrl: string;
  previewText: {
    greeting: string;
    name: string;
    jobTitle: string;
  };
  logoUrl?: string;
}

export interface UserCardData {
  name: string;
  jobTitle: string;
  selectedCardId: string | null;
}
