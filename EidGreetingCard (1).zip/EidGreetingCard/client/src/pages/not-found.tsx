export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
      <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-md mx-4">
        <div className="text-center mb-4">
          <h1 className="text-3xl font-bold text-red-500">404</h1>
          <h2 className="text-xl font-semibold mt-2">الصفحة غير موجودة</h2>
        </div>

        <p className="text-center text-gray-600 mt-4">
          الصفحة التي تبحث عنها غير موجودة أو تم نقلها.
        </p>
        
        <div className="mt-6 text-center">
          <a href="/" className="text-blue-500 hover:text-blue-700">
            العودة للصفحة الرئيسية
          </a>
        </div>
      </div>
    </div>
  );
}
