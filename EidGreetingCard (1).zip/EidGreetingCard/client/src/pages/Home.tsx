import CardGenerator from "../components/CardGenerator";

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="py-10">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl font-bold mb-4">تهنئكم شركة الوثيقة المعتمدة لوساطة التأمين بحلول عيد الفطر المبارك</h1>
          <p className="text-xl mb-4">وكل عام وانتم بخير</p>
          <p className="text-lg">نقدم لكم خدمة إصدار بطاقة التهنئة الخاصة بكم</p>
        </div>
      </section>

      {/* Card Generator Section */}
      <section className="py-6">
        <div className="container mx-auto px-4">
          <CardGenerator />
        </div>
      </section>
    </div>
  );
}