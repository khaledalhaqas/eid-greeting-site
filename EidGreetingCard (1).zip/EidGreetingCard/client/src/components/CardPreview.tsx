import { useState } from "react";
import { LOGO_URL, EID_TEMPLATE_URL } from "../assets/constants";

interface CardPreviewProps {
  name: string;
  jobTitle: string;
  onBack: () => void;
}

export default function CardPreview({ name, jobTitle, onBack }: CardPreviewProps) {
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState("");
  
  const handleDownload = () => {
    try {
      setDownloading(true);
      setError("");
      
      // Create a canvas with correct aspect ratio (portrait mode)
      const canvas = document.createElement("canvas");
      canvas.width = 1080;
      canvas.height = 1920; // Portrait mode for mobile
      const ctx = canvas.getContext("2d");
      
      if (!ctx) {
        throw new Error("Canvas context not available");
      }
      
      // First load the background image
      const bgImage = new Image();
      
      bgImage.onload = () => {
        // Draw background image
        ctx.drawImage(bgImage, 0, 0, canvas.width, canvas.height);
        
        // Configure text settings for black text 
        ctx.textAlign = "center";
        ctx.fillStyle = "#000000"; // Black text
        
        // Position text in the white space - moved higher up from bottom
        const nameYPosition = canvas.height * 0.78; // Position for name higher up from bottom
        
        // Draw name with larger font
        ctx.font = "bold 64px Tajawal";
        ctx.fillText(name, canvas.width / 2, nameYPosition);
        
        // Draw job title below the name with larger font
        if (jobTitle) {
          ctx.font = "48px Tajawal";
          ctx.fillText(jobTitle, canvas.width / 2, nameYPosition + 70);
        }
        
        // Create the download link directly without adding logo
        const dataUrl = canvas.toDataURL("image/png");
        const link = document.createElement("a");
        link.download = `eid-card-${name.replace(/\s+/g, "-")}.png`;
        link.href = dataUrl;
        link.click();
        
        setDownloading(false);
      };
      
      // Handle background image loading error
      bgImage.onerror = (e) => {
        console.error("Failed to load background image:", e);
        setError("تعذر تحميل صورة الخلفية");
        setDownloading(false);
      };
      
      // Start loading the background image - using base64 encoded image
      bgImage.src = EID_TEMPLATE_URL;
      
    } catch (err) {
      console.error("Error creating card:", err);
      setError("حدث خطأ أثناء إنشاء البطاقة");
      setDownloading(false);
    }
  };
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4 text-center">تصميم البطاقة</h2>
      
      {error && (
        <div className="bg-red-50 text-red-500 p-3 rounded-md mb-4 text-center">
          {error}
        </div>
      )}
      
      <div className="flex items-center justify-center space-x-4 space-x-reverse mb-8">
        <div className="text-center">
          <p className="font-bold text-xl text-gray-700 mb-1">{name || "اسم الموظف"}</p>
          {jobTitle && <p className="text-gray-600">{jobTitle}</p>}
        </div>
      </div>
      
      <div className="flex space-x-4 space-x-reverse justify-center">
        <button
          onClick={handleDownload}
          disabled={downloading}
          className="bg-blue-600 text-white py-3 px-6 rounded-md hover:bg-blue-700 transition-colors disabled:bg-blue-400 text-lg"
        >
          {downloading ? "جاري التحميل..." : "تحميل البطاقة"}
        </button>
        
        <button
          onClick={onBack}
          className="bg-gray-200 text-gray-800 py-3 px-6 rounded-md hover:bg-gray-300 transition-colors text-lg"
        >
          عودة للتعديل
        </button>
      </div>
    </div>
  );
}