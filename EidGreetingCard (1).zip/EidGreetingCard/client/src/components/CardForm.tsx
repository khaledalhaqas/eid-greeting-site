import { useState } from "react";
import { LOGO_URL, EID_TEMPLATE_URL } from "../assets/constants";

interface CardFormProps {
  onGenerateCard: (name: string, jobTitle: string) => void;
}

export default function CardForm({ onGenerateCard }: CardFormProps) {
  const [name, setName] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [error, setError] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name) {
      setError("يرجى إدخال الاسم");
      return;
    }
    
    setError("");
    onGenerateCard(name, jobTitle);
  };
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-center mb-6">
        <img 
          src={LOGO_URL} 
          alt="شركة الوثيقة المعتمدة لوساطة التأمين" 
          className="h-20 object-contain"
        />
      </div>
      
      <h2 className="text-xl font-bold mb-4 text-center">إنشاء بطاقة معايدة</h2>
      
      {error && (
        <div className="bg-red-50 text-red-500 p-3 rounded-md mb-4 text-center">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">
            الاسم <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
            placeholder="أدخل اسمك"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">
            المسمى الوظيفي
          </label>
          <input
            type="text"
            value={jobTitle}
            onChange={(e) => setJobTitle(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
            placeholder="أدخل المسمى الوظيفي"
          />
        </div>
        
        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
          >
            إنشاء البطاقة
          </button>
        </div>
      </form>
    </div>
  );
}