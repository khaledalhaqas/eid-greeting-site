import { useState } from "react";
import CardForm from "./CardForm";
import CardPreview from "./CardPreview";

export default function CardGenerator() {
  const [showPreview, setShowPreview] = useState(false);
  const [name, setName] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  
  const handleGenerateCard = (name: string, jobTitle: string) => {
    setName(name);
    setJobTitle(jobTitle);
    setShowPreview(true);
  };
  
  const handleBack = () => {
    setShowPreview(false);
  };
  
  return (
    <div className="max-w-md mx-auto">
      {showPreview ? (
        <CardPreview 
          name={name} 
          jobTitle={jobTitle}
          onBack={handleBack}
        />
      ) : (
        <CardForm onGenerateCard={handleGenerateCard} />
      )}
    </div>
  );
}