import type { Express } from "express";
import { createServer, type Server } from "http";
import { cardTemplates } from "./cardTemplates";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route to get all card templates
  app.get('/api/card-templates', (req, res) => {
    res.json(cardTemplates);
  });

  // API route to get a specific card template by ID
  app.get('/api/card-templates/:id', (req, res) => {
    const { id } = req.params;
    const template = cardTemplates.find(card => card.id === id);
    
    if (!template) {
      return res.status(404).json({ message: 'Card template not found' });
    }
    
    res.json(template);
  });

  // API route to validate captcha (simple implementation)
  app.post('/api/validate-captcha', (req, res) => {
    const { captcha } = req.body;
    
    // For this implementation, we'll accept any non-empty captcha
    // In a real implementation, you would validate against the actual captcha value
    if (!captcha) {
      return res.status(400).json({ message: 'Captcha is required' });
    }
    
    res.json({ valid: true });
  });

  const httpServer = createServer(app);

  return httpServer;
}
