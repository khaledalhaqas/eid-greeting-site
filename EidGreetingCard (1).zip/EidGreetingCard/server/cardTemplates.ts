
import { CardTemplate } from "../shared/schema";

// Define template URL directly for hardcoded use
const EID_TEMPLATE_URL = "/images/عيدكم مبارك كل عام وانتم بخير.jpg";
const COMPANY_LOGO = "/images/Logo1.jpg";
const COMPANY_LOGO_WHITE = "/images/APWhite.png";

export const cardTemplates: CardTemplate[] = [
  {
    id: "1",
    name: "بطاقة عرضية",
    orientation: "landscape",
    imageUrl: EID_TEMPLATE_URL,
    previewText: {
      greeting: "عيد مبارك",
      name: "اسم الموظف",
      jobTitle: "المسمى الوظيفي"
    },
    logoUrl: COMPANY_LOGO
  },
  {
    id: "2",
    name: "بطاقة طولية",
    orientation: "portrait",
    imageUrl: EID_TEMPLATE_URL,
    previewText: {
      greeting: "عيد مبارك",
      name: "اسم الموظف",
      jobTitle: "المسمى الوظيفي"
    },
    logoUrl: COMPANY_LOGO
  }
];
